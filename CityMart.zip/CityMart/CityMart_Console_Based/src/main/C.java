package main;

import java.util.Scanner;

public class C
{
	public static Scanner sc = new Scanner(System.in);
	public static String redbri = "\033[1;91m"; 
	public static String Orange = "\033[38;2;255;165;0m";
	public static String pink = "\033[38;2;255;105;180m";
	public static String carrot = "\033[38;2;237;145;33m";
	public static String lime = "\033[38;2;0;255;0m";
	public static String macha = "\033[38;2;120;185;67m";
	public static String navy = "\033[38;2;0;0;128m";
	public static String pool ="\033[38;2;64;224;208m";
	public static String ruby = "\033[38;2;224;17;95m";
	public static String apricot = "\033[38;2;251;206;177m";
	public static String plum = "\033[38;2;221;160;221m";
	public static String olive = "\033[38;2;128;128;0m";
	public static String turquoise = "\033[38;2;64;224;208m"; 
	public static String celadon ="\033[38;2;172;225;175m";
	public static String rosewood = "\033[38;2;101;0;11m"; 
	public static String beet = "\033[38;2;139;0;0m";
	public static String hotpink = "\033[38;2;255;105;180m";
	public static String charteuse ="\033[38;2;127;255;0m";
	public static String lightpink = "\033[38;2;255;182;193m";
	public static String seafoam = "\033[38;2;159;226;191m";
	public static  String armygreen ="\033[38;2;75;83;32m";
	public static String lightgrey ="\033[38;2;211;211;211m";
	public static String tan = "\033[38;2;210;180;140m";
	public static String emerald = "\033[38;2;80;200;120m";
	public static String reset="\u001B[0m";
	public static String bold="\u001B[1m";
	public static String blink="\u001B[5m";
	public static String red="\u001B[31m";
	public static String green="\u001B[32m";
	public static String yellow="\u001B[33m";
	public static String blue="\u001B[34m";
	public static String purple="\u001B[35m";
	public static String cyan="\u001B[36m";
	public static String white="\u001B[37m";
	public static String whitebg="\u001B[47m";
	public static String black ="\u001B[30m";
	public static String magent = "\u001B[95m";
	public static final String ital = "\u001B[3m";
	//bright colors;

	public static  String redbr = "\033[0;91m";  
	public static  String greenbr = "\033[0;92m"; 
	public static  String whitebr = "\033[0;97m";
	public static String ul = "\u001B[4m";
}
