package main;

public abstract class template
{
	public abstract void m1();

}
