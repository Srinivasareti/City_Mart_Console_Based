/**
 * 
 */
/**
 * 
 */
module CityMart_Console_Based {
}